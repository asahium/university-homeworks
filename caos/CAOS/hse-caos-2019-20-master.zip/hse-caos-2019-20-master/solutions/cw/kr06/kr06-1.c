((proc() && proc()) || (proc() && proc()))
