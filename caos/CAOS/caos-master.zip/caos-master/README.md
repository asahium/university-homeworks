# caos

Free to use. The only rule is "do not cheat".

Default build system is CMake -- set the contest/check index and the task number, and you will get two build targets -- 
for the check and for the consest, respectively.

Feel free to correct any mistakes (via a pull request) if found.
