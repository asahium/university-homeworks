unsigned A = 10;
unsigned B = 15;

void process();

int main() {
    process();
}