#include <stdio.h>
#include <sys/types.h>

int main() {
    int K;
    double y;
    scanf("%d %lf", &K, &y);

    pthread_t ids[K];

    for (int i = 0; i < K; ++i) {

    }
}