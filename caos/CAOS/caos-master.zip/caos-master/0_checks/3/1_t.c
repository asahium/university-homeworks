#include <stdio.h>

int X = 5;

//void minmax();

int process();

int main () {
    //minmax();
    printf("%d", process());
}
