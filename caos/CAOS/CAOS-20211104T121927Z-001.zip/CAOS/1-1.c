/*Код взят с семинара 194 группы*/
#include <stdio.h>
int main()
{
   int a, b;
   scanf("%d%d", &a, &b);
   
   int c = a + b;
   printf("%d\n", c);
   return 0;
}